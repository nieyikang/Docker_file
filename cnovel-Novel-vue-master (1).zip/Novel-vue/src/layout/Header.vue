<template>
    <div class="header" ref="headerDiv">
        <div class="hide-menu" @click="collapseChange">
            <i class="el-icon-s-fold"/>
        </div>
        <div class="header-right">
            <screenfull/>
            <!--右侧下拉框-->
            <el-dropdown @command="handleCommand">
                <div class="avatar user">
                    <el-avatar :size="size" :src="circleUrl" alt="用户头像" :key="circleUrl">
                        <img src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png" alt="失败头像"/>
                    </el-avatar>
                    <div>
                        <small v-text="name" class="user-name">VUE</small>
                    </div>
                </div>
                <!-- 用户名下拉菜单 -->
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item command="profile" icon="fa fa-user">个人中心</el-dropdown-item>
                    <el-dropdown-item command="disk" icon="el-icon-receiving" v-if="disk==='true'">个人网盘</el-dropdown-item>
                    <el-dropdown-item command="modifyPassword" icon="fa fa-key">修改密码</el-dropdown-item>
                    <el-dropdown-item command="logout" icon="fa fa-sign-out" divided>退出登录</el-dropdown-item>
                </el-dropdown-menu>
            </el-dropdown>
        </div>
        <el-dialog :title="dialog.title" :visible.sync="dialog.dialogFormVisible" @close="closeDialog"
                   :modal-append-to-body="false" width="30%">
            <el-form :model="modifyPasswordModel" ref="modifyPasswordForm" label-width="100px"
                     :rules="modifyPasswordRules"
                     size="small ">
                <el-form-item label="用户名">
                    <el-input v-model="userInfo.userName" placeholder="用户名" disabled/>
                </el-form-item>
                <el-form-item label="旧密码" prop="oldPassWord">
                    <el-input v-model="modifyPasswordModel.oldPassWord" placeholder="请输入旧密码" show-password/>
                </el-form-item>
                <el-form-item label="新密码" prop="newPassWord">
                    <el-input v-model="modifyPasswordModel.newPassWord" placeholder="请输入新密码" show-password/>
                </el-form-item>
                <el-form-item label="确认密码" prop="confirmPassword">
                    <el-input v-model="modifyPasswordModel.confirmPassword" placeholder="请确认密码" show-password/>
                </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialog.dialogFormVisible = false" size="medium"> 取 消</el-button>
                <el-button type="primary" @click="submitModifyPassword" size="medium"> 保 存</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script lang="ts">
    import {Component, Provide, Ref, Vue} from 'vue-property-decorator';
    import {Action, Getter} from 'vuex-class';
    import {MyDialog} from '*.vue';
    import {modifyPassword} from '@/api/profile';
    import Screenfull from '@/components/Screenfull/Screenfull.vue';
    import {getConfigKey} from "@/api/config";

    @Component({
        components: {
            Screenfull,
        },
    })
    export default class Header extends Vue {
        @Action('setCollapse') private setCollapse!: (collapse: boolean) => void;
        @Action('LogOut') private LogOut!: () => Promise<any>;
        @Getter('collapse') private collapse: any;
        @Getter('avatar') private circleUrl!: string;
        @Getter('userInfo') private userInfo!: any;
        @Ref('headerDiv') private headerDiv: any;
        @Ref('modifyPasswordForm') private mdPasswordForm: any;
        @Getter('name') private name!: string;
        @Getter('device') private device!: string;
        @Provide() private size = 'large';
        @Provide() private dialog: MyDialog = {
            dialogFormVisible: false,
            title: '修改密码',
        };

        private disk = 'false';
        modifyPasswordModel: any = {
            oldPassWord: '',
            newPassWord: '',
            confirmPassword: '',
        };

        private validatePass = (rule: any, value: any, callback: any) => {
            console.log(this.modifyPasswordModel);
            if (value === '') {
                callback(new Error('请再次输入密码'));
            } else if (value !== this.modifyPasswordModel.newPassWord) {
                callback(new Error('两次输入密码不一致!'));
            } else {
                callback();
            }
        };

        @Provide() private modifyPasswordRules: any = {
            oldPassWord: [
                {required: true, message: '原密码不能为空', trigger: ['blur']},
            ],
            newPassWord: [
                {required: true, message: '新密码不能为空', trigger: ['blur']},
            ],
            confirmPassword: [
                {required: true, message: '确认密码不能为空', trigger: ['blur']},
                {validator: this.validatePass, trigger: 'blur'},
            ],
        };


        public collapseChange() {
            this.setCollapse(!this.collapse);
        }

        public handleCommand(command: string) {
            if (command === 'logout') {
                this.$confirm('确定退出登录?', '退出登录', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning',
                }).then(() => {
                    return this.LogOut();
                }).then(() => {
                    location.reload();
                }).catch((e) => {
                    console.log(e);
                });
            } else if (command === 'profile') {
                this.$router.push('/user/profile').catch((e) => {
                    console.log(e);
                });
            } else if (command === 'disk') {
                window.open(process.env.VUE_APP_DISK + "/?token=" + this.$store.getters.token, "_blank")
            } else if (command === 'modifyPassword') {
                this.dialog.dialogFormVisible = true;
            }
        }

        public submitModifyPassword() {
            this.mdPasswordForm.validate((valid: boolean) => {
                if (valid) {
                    modifyPassword({
                        oldPassWord: this.modifyPasswordModel.oldPassWord,
                        newPassWord: this.modifyPasswordModel.newPassWord,
                    }).then((response: any) => {
                        this.dialog.dialogFormVisible = false;
                        this.$message.success(response.msg);
                        setTimeout(() => {
                            this.LogOut().then(() => {
                                location.reload();
                            }).catch((err: any) => {
                                console.log(err);
                            });
                        }, 500);
                    }).catch((e) => {
                        console.log(e);
                    });
                }
            });
        }

        /*重置表单*/
        reset(): void {
            this.mdPasswordForm.resetFields();
        }

        /*关闭对话框*/
        closeDialog() {
            this.$nextTick(() => {
                this.reset();
            });
        }

        created() {
            getConfigKey({configKey: "sys.index.disk"}).then((res: any) => {
                if (res) {
                    this.disk = res.data;
                }
            }).catch((err: any) => {
                console.log(err)
            })
        }
    }
</script>

<style scoped lang="scss">
    .header {
        height: 50px;
        background-color: #4AB7BD;


        .hide-menu {
            color: #ffffff;
            float: left;
            cursor: pointer;
            padding: 15px;
            line-height: 20px;
        }


        .header-right {
            float: right;
            height: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            margin-right: 20px;

            /*      &:hover {
                      background-color: #367fa9;
                  }*/
            .user {
                cursor: pointer;
            }

            .avatar {
                display: flex;
                justify-content: center;
                align-items: center;
                color: white;
                margin: auto 20px;
                width: 100px;

                .user-name {
                    margin-left: 10px;
                }
            }
        }
    }
</style>
