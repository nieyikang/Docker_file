<template>
    <div class="footer">
        <div class="pull-right">© {{copyrightYear}} {{copyrightCompany}} Copyright</div>
    </div>
</template>
<script lang="ts">
  import {Component, Prop, Vue} from 'vue-property-decorator';

  @Component
  export default class Footer extends Vue {
    @Prop({default: 'cnovel.club'}) private copyrightCompany!: string;
    @Prop({default: '2020'}) private copyrightYear!: string;
  }
</script>

<style scoped lang="scss">
    .pull-right {
        float: right !important;
        padding-right: 20px;
    }

    .footer {
        width: 100%;
        height: 38px;
        color: #333;
        line-height: 38px;
        font-size: 13px;
        background: none repeat scroll 0 0 white;
        border-top: 1px solid #e7eaec;
        overflow: hidden;
    }
</style>

