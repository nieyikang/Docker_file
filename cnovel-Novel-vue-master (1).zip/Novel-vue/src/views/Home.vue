<template>
    <div class="home">
        <el-row :gutter="20">
            <el-col :sm="24" :lg="12" class="col-item">
                <h2>novel后台管理框架</h2>

                <p>
                    一直想做一款后台管理系统，看了很多优秀的开源项目，从中发现了若依开源框架，从她出现以来就一直关注，但发现其中的功能太过强大，部分功能也不太适合自己，并且自己也一直想要动手学习一下若依的强大之处，便有了自己现在的novel。
                </p>
                <p>
                    它可以用于所有的Web应用程序，如网站管理后台，网站会员中心，CMS，CRM，OA等等，当然，您也可以对她进行深度定制，以做出更强系统。所有前端后台代码封装过后十分精简易上手，出错概率低。同时支持移动客户端访问。系统会陆续更新一些实用功能。
                </p>
                <p>
                    <b>当前版本:</b> <span>v{{projectInfo.version}}</span>
                </p>
                <p>
                    <el-button-group>
                        <el-button type="primary" round size="mini" icon="fa fa-cloud" @click="toVue()"> 前端
                        </el-button>
                        <el-button type="primary" round size="mini" icon="fa fa-cloud" @click="toSpringBoot()">
                            后端
                        </el-button>
                        <el-button type="primary" round size="mini" icon="fa fa-home" @click="toHome()"> 主页
                        </el-button>
                    </el-button-group>
                </p>
            </el-col>
            <el-col :sm="24" :lg="12" class="col-item">
                <el-row>
                    <el-col :span="12">
                        <h2>技术选型</h2>
                    </el-col>
                </el-row>
                <el-row>

                    <el-col :span="6">
                        <h4>
                            后端技术
                        </h4>
                        <ul>
                            <li>SpringBoot</li>
                            <li>Apache Shiro</li>
                            <li>jwt</li>
                            <li>MyBatis</li>
                            <li>Druid</li>
                            <li>Fastjson</li>
                            <li>oss</li>
                            <li>...</li>
                        </ul>
                    </el-col>
                    <el-col :span="6">
                        <h4>前端技术</h4>
                        <ul>
                            <li>vue</li>
                            <li>TypeScript</li>
                            <li>Sass</li>
                            <li>element-ui</li>
                            <li>vuex</li>
                            <li>axios</li>
                            <li>...</li>
                        </ul>
                    </el-col>
                </el-row>
            </el-col>
        </el-row>
        <el-divider/>
        <el-row :gutter="20">
            <el-col :xs="24" :sm="24" :md="12" :lg="8">
                <el-card class="update-log">
                    <div slot="header" class="clearfix">
                        <span>更新日志</span>
                    </div>
                    <el-collapse accordion>
                        <el-collapse-item title="v1.6.0 - 2020.08.10">
                            <ol>
                                <li>新增个人网盘功能</li>
                                <li>新增接口文档</li>
                                <li>线上cdn优化</li>
                                <li>修复登录时路由重定向出现的异常</li>
                                <li>修复passive-events导致的页面警告</li>
                                <li>更新项目依赖</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.5.0 - 2020.07.09">
                            <ol>
                                <li>新增参数配置管理</li>
                                <li>更新fastjson，加固系统漏洞</li>
                                <li>更新本地ip库信息，修复淘宝ip查询问题</li>
                                <li>修复代码生成mapper xml等问题</li>
                                <li>更新项目依赖</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.4.3 - 2020.04.17">
                            <ol>
                                <li>添加后端数据校验回显到表单功能</li>
                                <li>优化在线用户查询速度，多次查询改为批量查询</li>
                                <li>优化redis查询</li>
                                <li>新增xss攻击过滤</li>
                                <li>更新项目依赖</li>
                                <li>更新本地ip库</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.4.2 - 2020.04.08">
                            <ol>
                                <li>修复本地ip获取出现‘0’的问题</li>
                                <li>修复代码生成出现‘id’排序问题</li>
                                <li>更新e-icon-picker版本，新版本解决了es6问题</li>
                                <li>修复菜单添加错误信息未显示问题以及添加错误问题</li>
                                <li>修复修改密码时，两次密码不一致错误以及dialog未及时清空问题</li>
                                <li>优化角色菜单树选择功能</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.4.1 - 2020.03.31">
                            <ol>
                                <li>添加代码规范配置eslint</li>
                                <li>添加七牛云文件存储实现</li>
                                <li>修复界面热更新界面白屏问题</li>
                                <li>修复打包时uglifyjs-webpack-plugin插件对es6代码报错问题</li>
                                <li>更新fastjson到1.2.68，安全加固</li>
                                <li>更新springboot到2.2.6</li>
                                <li>其他优化</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.4.0 - 2020.03.26">
                            <ol>
                                <li>添加代码生成功能</li>
                                <li>添加菜单目录默认跳转路径</li>
                                <li>修复当添加菜单时，切换菜单类型，自动重置表单校验</li>
                                <li>修复全屏显示按钮点击文字以外的位置不能正常点击问题</li>
                                <li>添加Axios对数据流的处理</li>
                                <li>添加对数据流的下载</li>
                                <li>其他优化</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.3.1 - 2020.03.24">
                            <ol>
                                <li>修复当用户再次打开菜单时，数据不自动更新问题</li>
                                <li>去除表单验证时的加载动画</li>
                                <li>修复编辑信息不能正常清空</li>
                                <li>关闭对话框事件进行优化</li>
                                <li>修复点击头像下拉框外面时的鼠标样式</li>
                                <li>修复datatable排序图标换行问题</li>
                                <li>优化Axios请求，添加消息框显示控制参数</li>
                                <li>显示loading动画参数从view调至api中</li>
                                <li>升级e-icon-picker到最新版本，修复图标选择器在ie下不能正常使用问题</li>
                                <li>将vue-cropper组件替换为最新版本</li>
                                <li>调整登录界面验证码的获取时间，避免用户等待</li>
                                <li>修复刷新页面时，路由不能正常被激活的问题</li>
                                <li>修复新增定时任务时出现的任务id错误</li>
                                <li>修改验证码异常，重新对异常进行处理</li>
                                <li>添加Ip2Region查找ip工具</li>
                                <li>其他优化</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.3.0 - 2020.03.3">
                            <ol>
                                <li>新增任务调度功能</li>
                                <li>新增用户导入功能</li>
                                <li>新增任务调度信息导出</li>
                                <li>新增任务调度日志导出</li>
                                <li>新增datatable、treetable可以对超出部分文字进行隐藏</li>
                                <li>修复菜单新增时改变类型导致的按钮存在隐藏属性</li>
                                <li>修复菜单控件不能隐藏菜单问题</li>
                                <li>更新vue组件依赖版本</li>
                                <li>更新springboot等组件版本</li>
                                <li>优化java代码</li>
                                <li>其他问题优化</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.2.2 - 2020.01.14">
                            <ol>
                                <li>新增记住登录功能</li>
                                <li>新增全屏显示功能</li>
                                <li>新增api端下载初始化文档</li>
                                <li>调整layout组件单独分类</li>
                                <li>调整vuex模块化分类</li>
                                <li>调整服务监控页面进行自适应兼容</li>
                                <li>调整个人信息页面进行自适应兼容</li>
                                <li>修复操作日志查询问题</li>
                                <li>修复因字体 Helvetica 问题产生的文字高度不一致问题</li>
                                <li>其他问题修复</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.2.1 - 2020.01.07">
                            <ol>
                                <li>新增cos和minio文件存储功能</li>
                                <li>修改了oss的初始化方式为builder，同步官网</li>
                                <li>调整了在程序启动时自动检测创建bucketName</li>
                                <li>修复部门新增和修改时，上级部门为空时出现的异常</li>
                                <li>更换了网站图标</li>
                                <li>修复了当ie浏览器在https下不能访问http图片问题</li>
                                <li>添加项目介绍部署等说明文档</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.2.0 - 2019.12.30">
                            <ol>
                                <li>添加表单搜索默认事件</li>
                                <li>添加excel数据导出</li>
                                <li>添加前端异步数据校验</li>
                                <li>添加后端数据校验</li>
                                <li>优化验证码缓存</li>
                            </ol>
                        </el-collapse-item>

                        <el-collapse-item title="v1.1.1 - 2019.12.20">
                            <ol>
                                <li>新增用户登录日志管理</li>
                                <li>调整界面在小屏幕下的兼容性问题</li>
                                <li>修复数据监控iframe嵌套问题</li>
                                <li>修复新版本ui发布时本地存储的信息解析问题</li>
                            </ol>
                        </el-collapse-item>
                        <el-collapse-item title="v1.1.0 - 2019.12.17">
                            <ol>
                                <li>新增数据库等密码配置属性加密功能</li>
                                <li>新增在线用户管理功能</li>
                                <li>新增数据监控功能</li>
                                <li>新增用户管理密码重置功能</li>
                                <li>修复用户信息修改导致用户权限等信息不能及时更新问题</li>
                                <li>修复修复token刷新问题</li>
                                <li>统一处理缓存问题</li>
                            </ol>
                        </el-collapse-item>
                        <el-collapse-item title="v1.0.0 - 2019.12.06">
                            <ol>
                                <li>novel管理系统正式发布</li>
                            </ol>
                        </el-collapse-item>
                    </el-collapse>
                </el-card>
            </el-col>
            <el-col :xs="24" :sm="24" :md="12" :lg="8">
                <el-card class="update-log">
                    <div slot="header" class="clearfix">
                        <span>捐赠支持</span>
                    </div>
                    <div class="body">
                        <img src="https://oscimg.oschina.net/oscnet/up-e2344cd770f7f7386637d0dbbfb5d48472c.JPEG" alt=""
                             width="100%">
                        <span style="display: inline-block;height: 30px;line-height: 30px">捐赠时添加一个备注，以便展示捐赠者名单。</span>
                    </div>
                </el-card>
            </el-col>
            <el-col :xs="24" :sm="24" :md="12" :lg="8">
                <el-card class="update-log">
                    <div slot="header" class="clearfix">
                        <span>服务器购买</span>
                    </div>
                    <div class="body">
                        <a href="https://www.aliyun.com/sale-season/2020/procurement-new-members?userCode=imu9ntnh" target="_blank"><img src="http://qiniu.cnovel.club/%E9%87%87%E8%B4%AD%E5%AD%A3%E4%BA%91%E5%A4%A7%E4%BD%BF%E4%B8%93%E4%BA%AB%E7%B4%A0%E6%9D%90/540_130.png" alt="" width="100%"></a>
                        <a href="https://cloud.tencent.com/act/cps/redirect?redirect=1054&cps_key=222143f4d336655560a8b4ecd8943a19&from=console" target="_blank"><img src="http://qiniu.cnovel.club/%E9%87%87%E8%B4%AD%E5%AD%A3%E4%BA%91%E5%A4%A7%E4%BD%BF%E4%B8%93%E4%BA%AB%E7%B4%A0%E6%9D%90/560.300.jpg" alt="" width="100%"></a>
                    </div>
                </el-card>
            </el-col>
        </el-row>
    </div>
</template>
<script lang="ts">
  import {Component, Vue} from 'vue-property-decorator';
  import {Getter} from 'vuex-class';

  @Component({
    components: {}
  })
  export default class Home extends Vue {
    @Getter('projectInfo') private projectInfo!: any;

    toVue() {
      window.open('https://gitee.com/cnovel/Novel-vue', '_blank');
    }

    toSpringBoot() {
      window.open('https://gitee.com/cnovel/Novel-api', '_blank');
    }

    toHome() {
      window.open('http://cnovel.club', '_blank');
    }
  }
</script>

<style scoped lang="scss">
    .home {
        .col-item {
            margin-bottom: 20px;
        }

        font-family: "open sans", "Helvetica Neue", Helvetica, Arial, sans-serif;
        font-size: 13px;
        color: #676a6c;
        overflow-x: hidden;

        ul {
            list-style-type: none;
        }


        h4 {
            margin-top: 10px;
        }


        h2 {
            margin-top: 10px;
            font-size: 26px;
            font-weight: 100;
        }

        p {
            margin-top: 10px;

            b {
                font-weight: 700;
            }
        }

        .update-log {
            ol {
                display: block;
                list-style-type: decimal;
                margin-block-start: 1em;
                margin-block-end: 1em;
                margin-inline-start: 0;
                margin-inline-end: 0;
                padding-inline-start: 40px;
            }
        }
    }
</style>

