<template>
    <div class="login">
        <el-form ref="loginForm" :model="loginForm" :rules="loginRules" class="login-form">
            <h3 class="title">{{projectInfo.name}} 后台管理系统</h3>
            <el-form-item prop="username">
                <el-input v-model="loginForm.userName" type="text" auto-complete="off" placeholder="账号">
                </el-input>
            </el-form-item>
            <el-form-item prop="password">
                <el-input
                        v-model="loginForm.password"
                        type="password"
                        auto-complete="off"
                        placeholder="密码"
                        @keyup.enter.native="handleLogin"
                >
                </el-input>
            </el-form-item>
            <el-form-item prop="code">
                <el-input
                        v-model="loginForm.code"
                        auto-complete="off"
                        placeholder="验证码"
                        style="width: 63%"
                        @keyup.enter.native="handleLogin"
                >
                </el-input>
                <div class="login-code">
                    <img :src="codeUrl" alt="" @click="getCode"/>
                </div>
            </el-form-item>
            <el-checkbox v-model="loginForm.rememberMe" style="margin:0 0 25px 0;">记住密码</el-checkbox>
            <el-form-item style="width:100%;">
                <el-button
                        :loading="loading"
                        size="medium"
                        type="primary"
                        style="width:100%;"
                        @click.native.prevent="handleLogin"
                >
                    <span v-if="!loading">登 录</span>
                    <span v-else>登 录 中...</span>
                </el-button>
            </el-form-item>
        </el-form>

        <!--  底部  -->
        <div class="el-login-footer">
            <span>Copyright © {{projectInfo.copyrightYear}} {{projectInfo.copyrightCompany}} All Rights Reserved.</span>
            <p>
                <a target="_blank" href="http://www.beian.miit.gov.cn" v-html="projectInfo.icp">湘ICP备xxxxxxxx号</a>
            </p>
        </div>
    </div>
</template>

<script lang="ts">
    import {Component, Provide, Vue, Watch} from 'vue-property-decorator';
    import {Action, Getter} from 'vuex-class';
    import {getKaptchaImage} from '@/api/common';

    @Component
    export default class Login extends Vue {

        codeUrl = '';
        @Getter('projectInfo') private projectInfo: any;

        @Provide()
        cookiePassword = '';
        @Provide()
        loginForm: {
            userName: string;
            password: string;
            rememberMe: boolean;
            code: string;
            key: string;
        } = {
            userName: 'admin',
            password: '123456',
            rememberMe: false,
            code: '',
            key: ''
        };
        private redirect: any;
        private query: any;
        @Provide()
        loginRules = {
            userName: [
                {required: true, trigger: 'blur', message: '用户名不能为空'}
            ],
            password: [
                {required: true, trigger: 'blur', message: '密码不能为空'}
            ],
            code: [{required: true, trigger: 'change', message: '验证码不能为空'}]
        };
        @Provide()
        private loading = false;

        @Action('Login') private Login!: (loginForm: any) => any;

        handleLogin(): void {
            (this.$refs.loginForm as any).validate((valid: boolean) => {
                if (valid) {
                    this.loading = true;
                    this.Login(this.loginForm).then((res: any) => {
                        this.loading = false;
                        let path = '/';
                        if (this.redirect) {
                            path = this.redirect;
                        }
                        return this.$router.push({path: path, query: this.query});
                    }).catch((err: any) => {
                        console.log(err);
                        this.loading = false;
                        this.getCode();
                    });
                }
            });
        }

        getCode() {
            getKaptchaImage().then((res: any) => {
                this.codeUrl = res.data.base64Image;
                this.loginForm.key = res.data.key;
            }).catch((err: any) => {
                console.log(err);
            });
        }

        created() {
            this.getCode();
        }

        @Watch('$route', {immediate: true})
        onRouteChanged(route: any) {
            this.redirect = route.query && route.query.redirect;
            this.query = route.query;
            if (this.query) {
                delete this.query.redirect;
            }
        }

    }
</script>

<style lang="scss" scoped>
    .login {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        background-image: url("../assets/image/login-background.jpg");
        background-size: cover;
    }

    .title {
        margin: 0 auto 30px auto;
        text-align: center;
        color: #707070;
    }

    .login-form {
        border-radius: 6px;
        background: #ffffff;
        width: 400px;
        padding: 25px 25px 5px 25px;

        .el-input {
            height: 38px;

            input {
                height: 38px;
            }
        }

        .input-icon {
            height: 39px;
            width: 14px;
            margin-left: 2px;
        }
    }

    .login-tip {
        font-size: 13px;
        text-align: center;
        color: #bfbfbf;
    }

    .login-code {
        width: 33%;
        height: 38px;
        float: right;

        img {
            height: 100%;
            width: 100%;
            cursor: pointer;
        }
    }

    .el-login-footer {
        height: 80px;
        line-height: 40px;
        position: fixed;
        bottom: 0;
        width: 100%;
        text-align: center;
        color: #fff;
        font-family: Arial, serif;
        font-size: 12px;
        letter-spacing: 1px;

        p a {
            color: #ffffff;
            line-height: 25px;
        }
    }
</style>
