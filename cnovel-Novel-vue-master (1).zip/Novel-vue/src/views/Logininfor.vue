<template>
    <div class="tableRow">
        <el-row class="select-list" v-permission="'system:logininfor:query'">
            <el-form :inline="true" ref="selectForm" :model="selectFormModel" :label-position="'right'"
                     label-width="80px" size="mini">
                <el-form-item label="登录地址" prop="ipaddr">
                    <el-input v-model="selectFormModel.ipaddr" placeholder="登录地址" style="width: 200px" clearable
                              @keyup.enter.native="onSearch"/>
                </el-form-item>
                <el-form-item label="用户名称" prop="userName">
                    <el-input v-model="selectFormModel.userName" placeholder="用户名称" style="width: 200px" clearable
                              @keyup.enter.native="onSearch"/>
                </el-form-item>
                <el-form-item label="状态" prop="status">
                    <el-select value="" v-model="selectFormModel.status" placeholder="状态" style="width: 200px">
                        <el-option label="成功" value="0"/>
                        <el-option label="失败" value="1"/>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" icon="el-icon-search" size="mini" plain round @click="onSearch">搜索
                    </el-button>
                    <el-button type="warning" icon="el-icon-refresh" size="mini" plain round
                               @click="onRefreshSelectForm">重置
                    </el-button>
                </el-form-item>
            </el-form>
        </el-row>
        <el-row class="toolbar">
            <el-button type="danger" icon="el-icon-delete" :disabled="dialog.isBatchRemoveDisabled" size="mini" plain
                       @click="handleBatchDelete" v-permission="'system:logininfor:remove'"> 删除
            </el-button>
            <el-button type="danger" icon="fa fa-remove" size="mini" @click="handleClean"
                       v-permission="'system:logininfor:clean'"> 清空
            </el-button>
            <el-button type="warning" icon="fa fa-download" size="mini" plain @click="handleExport"
                       v-permission="'system:logininfor:export'"> 导出
            </el-button>
        </el-row>
        <data-table ref="dataTable"
                    :options="options"
                    :operates="operates"
                    :api="getLogininforList"
                    :columns="columns"
                    :query="selectFormModel"
                    @handle-selection-change="handleSelectionChange"
        />
    </div>
</template>
<script lang="ts">
  import {Component, Ref, Vue} from 'vue-property-decorator';
  import {cleanLogininfor, exportLogininfor, getLogininforList, removeLogininfor} from '@/api/logininfor';
  import DataTable from '@/components/DataTable/DataTable.vue';

  @Component({
    components: {
      DataTable
    }
  })
  export default class Logininfor extends Vue {
    private getLogininforList: Function = getLogininforList;
    @Ref('dataTable') private dataTable: any;
    @Ref('selectForm') private selectForm: any;

    selectFormModel: any = {
      ipaddr: '',
      userName: '',
      status: ''
    };
    /*列信息*/
    columns: any = [
      {label: 'ID', prop: 'id', sortable: 'custom'},
      {label: '用户名称', prop: 'userName', sortable: 'custom'},
      {label: '登录地址', prop: 'ipaddr', sortable: 'custom', showOverflowTooltip: true},
      {label: '登录地点', prop: 'loginLocation', sortable: 'custom', showOverflowTooltip: true},
      {label: '浏览器', prop: 'browser'},
      {label: '操作系统', prop: 'os', sortable: 'custom'},
      {
        label: '登录状态', prop: 'status', sortable: 'custom', render: function (createElement, row) {
          if (row && row.row && row.row.status === '0') {
            return createElement('el-tag', {
                attrs: {
                  type: 'success'
                }
              }, ['成功']
            );
          } else if (row && row.row && row.row.status === '1') {
            return createElement('el-tag', {
                attrs: {
                  type: 'danger'
                }
              }, ['失败']
            );
          } else {
            return createElement('el-tag', {
                attrs: {
                  type: 'danger'
                }
              }, ['未知']
            );
          }
        }
      },
      {label: '操作信息', prop: 'msg'},
      {label: '登录日期', prop: 'loginTime', sortable: 'custom', showOverflowTooltip: true},
    ];
    // table 的参数
    options: any = {
      stripe: true, // 是否为斑马纹 table
      loading: false, // 是否添加表格loading加载动画
      highlightCurrentRow: true, // 是否支持当前行高亮显示
      multipleSelect: true, // 是否支持列表项选中功能
    };
    /*操作栏*/
    operates: any = {
      title: '操作',
      width: 'auto',
      fixed: 'right',
      list: [
        {
          label: '删除',
          type: 'danger',
          icon: 'el-icon-delete',
          plain: true,
          disabled: (index, row) => {
            return false;
          },
          permission: 'system:logininfor:remove',
          method: (index, row) => {
            this.handleDelete(index, row);
          }
        }
      ]
    };
    dialog: any = {
      isBatchEditDisabled: true,
      isBatchRemoveDisabled: true,
      formData: []
    };

    /*删除*/
    handleDelete(index: number, row: any) {
      this.$confirm('确定要删除该登录信息吗？', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        return removeLogininfor({'ids': [row.id]});
      }).then((response: any) => {
        this.dataTable.refresh();
        this.$message.success(response.msg);
      }).catch((e) => {
        console.log(e);
      });
    }

    /*选中事件*/
    handleSelectionChange(val): void {
      if (val) {
        this.dialog.isBatchRemoveDisabled = val.length <= 0;
        this.dialog.isBatchEditDisabled = val.length !== 1;
      }
      this.dialog.formData = val;
    }

    /*批量删除*/
    handleBatchDelete() {
      this.$confirm('确定要删除选定登录信息吗？', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const ids: Array<any> = [];
        this.dialog.formData.forEach((item, index) => {
          ids[index] = item.id;
        });
        return removeLogininfor({'ids': ids});
      }).then((response: any) => {
        this.dataTable.refresh();
        this.$message.success(response.msg);
      }).catch((e) => {
        console.log(e);
      });
    }


    /*清空*/
    handleClean(): void {
      this.$confirm('确定要清空所有登录日志吗？【此操作不可逆】', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'error'
      }).then(() => {
        return cleanLogininfor();
      }).then((response: any) => {
        this.dataTable.refresh();
        this.$message.success(response.msg);
      }).catch((e) => {
        console.log(e);
      });
    }

    /*导出excel*/
    handleExport(): void {
      this.$confirm('确定要导出当前查询的所有登录日志吗？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'info'
      }).then(() => {
        this.selectFormModel.pageNum = null;
        this.selectFormModel.pageSize = null;
        this.selectFormModel.orderByColumn = 'id';
        this.selectFormModel.isAsc = 'asc';

        return exportLogininfor(this.selectFormModel);
      }).then((response: any) => {
        console.log(response);
        if (response && response.data) {
          (this as any).$download(response.data.fileName);
        }
      }).catch((e) => {
        console.log(e);
      });
    }

    /*搜索*/
    onSearch(): void {
      this.dataTable.refresh();
    }


    /*重置*/
    onRefreshSelectForm(): void {
      //恢复搜索默认信息
      this.selectForm.resetFields();
      this.onSearch();
    }

  }
</script>

<style scoped lang="scss">

</style>

