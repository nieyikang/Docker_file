<template>
    <iframe-component class="iframe" :url="url"/>
</template>
<script lang="ts">
  import {Component, Vue} from 'vue-property-decorator';
  import IframeComponent from '@/components/Iframe/IframeComponent.vue';

  @Component({
    components: {
      IframeComponent
    }
  })
  export default class Druid extends Vue {
    private url = '/druid/index.html';
  }
</script>

<style scoped lang="scss">

</style>

