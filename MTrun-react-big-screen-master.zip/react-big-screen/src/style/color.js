export const TitleColor = '#bcdcff'
